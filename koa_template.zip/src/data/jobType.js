const arr = [{
  name: '技术类',
  key: 'code'
}, {
  name: '产品类',
  key: 'product'
}, {
  name: '兼职类',
  key: 'concurrent'
}, {
  name: '其它类',
  key: 'other'
}, {
  name: '设计类',
  key: 'design'
}, {
  name: '内容类',
  key: 'content'
}, {
  name: '财务类',
  key: 'finance'
}, {
  name: '行政支持类',
  key: 'administration'
}, {
  name: '人力资源类',
  key: 'humanResources'
}, {
  name: '营销与公关类',
  key: 'market'
}, {
  name: '战略与投资类',
  key: 'strategy'
}, {
  name: '法律与公共策略类类',
  key: 'law'
}, {
  name: '销售、服务与支持类',
  key: 'sale'
}]

module.exports = arr
